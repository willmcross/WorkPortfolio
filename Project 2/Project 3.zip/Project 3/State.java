/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3new;

/**
 *
 * @author Kanau
 */
public class State {
    Driver temp = new Driver();
    public int population, numregion;
    public String capital, abbreviation, region;
    
    public int getPop(int population){
        this.population = temp.population; 
        return this.population;
    }    

    public int getNumreg(int numregion){
        this.numregion = temp.numregion;
        return this.numregion;
    }

    public String getCap(String capital){
        this.capital = temp.capital;
        return this.capital;
    }

    public String getAbbr(String abbreviation){
        this.abbreviation = temp.abbreviation;
        return this.abbreviation;
    }

    public String getRegion(String Region){
        this.region = temp.region;
        return this.region;
    }

}
