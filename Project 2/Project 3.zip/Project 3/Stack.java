/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RachelBennett
 */
public class Stack implements Stackable {
    private Node top;
    
    public void push(Node item){
        item.setNext(top);
        top = item;
    }    
    
    public Node pop() {
        Node temp = top;
        top = temp.getNext();
        return temp;
    }
    
    public void display() {
        Node temp = top;
        while(temp !=null){
            System.out.println(temp.getValue());
            temp = temp.getNext();
        }
    }
    public boolean isEmpty() {
        return top ==null;
    }
    public boolean isFull() {
        return false;
    }
    
}
