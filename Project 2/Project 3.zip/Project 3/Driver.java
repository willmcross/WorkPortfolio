/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3new;

/**
 *
 * @author Kanau
 */
public class Driver {
    
    public void execute(){
        
    }
    
PriorityQueue q = new PriorityQueue();
Stack a = new Stack();
Stack d = new Stack();
Stack u = new Stack();
    
    public int population, numregion;
    public String capital, abbreviation, region;
    
    
    
    
}
