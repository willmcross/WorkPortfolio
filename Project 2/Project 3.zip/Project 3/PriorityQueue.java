/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RachelBennett
 */
public class PriorityQueue implements Queueable {
    private Node front;
    private Node rear;
        /**
     * Displays the items stored in the queue.
     */
    public void display(){
        Node temp = front;
        
        while (temp != null){
            System.out.println(temp.getValue());
            temp = temp.getNext();
        }
    }    
    /**
     * Displays the items in the queue from front to rear.
     */
    public void frontDisplay(){
        Node temp = front;
        
        while (temp != null){
            System.out.println(temp.getValue());
            temp = temp.getNext();
        }
    }
    /**
     * Adds a State object to the appropriate location of the queue.
     *
     * Note:  The isFull method should be called first to prevent errors.
     * @param state The State to add.
     */
    public void insert(State state){
        isFull();
        if(front = null){
            front = state;
            rear = state;
        }
        else{
            rear.setNext(state);
            rear = state;
        }
    }
    /**
     * Determines if the queue is empty.
     * @return True if the queue is empty; otherwise, false.
     */
    public boolean isEmpty(){
        return front == null;
    }
    /**
     * Determines if the queue is full.
     * @return True if the queue is full; otherwise, false.
     */
    public boolean isFull(){
        return false;
    }
    /**
     * Displays the items in the queue from rear to front.
     */
    public void rearDisplay(){
        Node temp = rear;
        
        while (temp != null){
            System.out.println(temp.getValue());
            temp = temp.getPrevious();
        }
    }
    /**
     * Removes a State object from the front of the queue.
     * 
     * Note:  The isEmpty method should be called first to prevent errors.
     * @return The State object that was removed.
     */
    public State remove(){
        isEmpty();
        Node temp = front;
        front = front.getNext();
        return temp;
    }
   /**
     * Removes a State object from the front of the queue.
     * 
     * Note:  The isEmpty method should be called first to prevent errors.
     * @param itemName The name of the State object to search for and remove.
     * @return The State object that was removed.
     */
    public State remove(String itemName){
        isEmpty();
    }
}
    
